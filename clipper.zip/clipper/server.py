import json, os, re, shutil, subprocess, threading, uuid, zipfile
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

DATA = Path("data"); DATA.mkdir(exist_ok=True)
MODEL = os.getenv("CLIP_MODEL", "claude-sonnet-5-5")
WHISPER = os.getenv("WHISPER_MODEL", "small")
app = FastAPI()
JOBS = {}

class Req(BaseModel):
    url: str
    count: int = 10
    min_len: int = 20
    max_len: int = 60
    vertical: bool = True
    captions: bool = True

def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if r.returncode: raise RuntimeError(r.stderr[-400:])

def transcribe(video: Path):
    from faster_whisper import WhisperModel
    audio = video.with_suffix(".wav")
    run(["ffmpeg", "-y", "-i", str(video), "-ac", "1", "-ar", "16000", str(audio)])
    model = WhisperModel(WHISPER, compute_type="int8")
    segs, _ = model.transcribe(str(audio), word_timestamps=True, vad_filter=True)
    out = []
    for s in segs:
        out.append({"start": s.start, "end": s.end, "text": s.text.strip(),
                    "words": [(w.start, w.end, w.word.strip()) for w in (s.words or [])]})
    return out

def pick_with_claude(segs, n, lo, hi):
    import anthropic
    lines = "\n".join(f"[{s['start']:.0f}-{s['end']:.0f}] {s['text']}" for s in segs)[:150000]
    prompt = (f"Pick the {n} best moments for short social clips from this transcript. "
              f"Each clip {lo}-{hi} seconds, self-contained, strong hook at the start, no overlaps. "
              f"Return ONLY a JSON list of objects with start, end (seconds) and title. "
              f"Fewer than {n} is fine if the video lacks good moments.\n\n{lines}")
    msg = anthropic.Anthropic().messages.create(model=MODEL, max_tokens=4000,
          messages=[{"role": "user", "content": prompt}])
    text = "".join(b.text for b in msg.content if b.type == "text")
    return json.loads(re.search(r"\[.*\]", text, re.S).group(0))

def pick_simple(segs, n, lo, hi):
    if not segs: return []
    end, win, scored, t = segs[-1]["end"], (lo + hi) / 2, [], 0
    while t + lo <= end:
        words = sum(len(s["text"].split()) for s in segs if t <= s["start"] < t + win)
        hype = sum(s["text"].count("?") + s["text"].count("!") for s in segs if t <= s["start"] < t + win)
        scored.append((words + 5 * hype, t)); t += win / 2
    chosen = []
    for _, t in sorted(scored, reverse=True):
        if all(abs(t - c) >= win for c in chosen): chosen.append(t)
        if len(chosen) == n: break
    return [{"start": t, "end": min(t + win, end), "title": f"Clip at {int(t)}s"} for t in sorted(chosen)]

def ass_time(t):
    h, m, s = int(t // 3600), int(t % 3600 // 60), t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

def make_ass(segs, start, end, path):
    words = [(a - start, b - start, w) for s in segs for a, b, w in s["words"] if a >= start and b <= end]
    head = ("[Script Info]\nPlayResX: 1080\nPlayResY: 1920\n\n[V4+ Styles]\n"
            "Format: Name,Fontname,Fontsize,PrimaryColour,OutlineColour,BackColour,Bold,Outline,Shadow,Alignment,MarginV\n"
            "Style: C,DejaVu Sans,78,&H00FFFFFF,&H00000000,&H00000000,1,6,0,2,420\n\n"
            "[Events]\nFormat: Layer,Start,End,Style,Text\n")
    lines = []
    for i in range(0, len(words), 3):
        g = words[i:i + 3]
        lines.append(f"Dialogue: 0,{ass_time(g[0][0])},{ass_time(g[-1][1])},C,{' '.join(x[2] for x in g).upper()}")
    Path(path).write_text(head + "\n".join(lines), encoding="utf-8")

def process(job_id, r: Req):
    job, d = JOBS[job_id], DATA / job_id
    d.mkdir(exist_ok=True)
    try:
        job.update(stage="Downloading video", pct=5)
        run(["yt-dlp", "-f", "bv*[height<=1080]+ba/b", "--merge-output-format", "mp4",
             "--no-playlist", "-o", str(d / "source.%(ext)s"), r.url])
        src = d / "source.mp4"
        job.update(stage="Transcribing audio", pct=20)
        segs = transcribe(src)
        job.update(stage="Finding the best moments", pct=50)
        n, lo, hi = max(1, min(50, r.count)), r.min_len, r.max_len
        try:
            moments = pick_with_claude(segs, n, lo, hi) if os.getenv("ANTHROPIC_API_KEY") else pick_simple(segs, n, lo, hi)
        except Exception:
            moments = pick_simple(segs, n, lo, hi)
        moments = moments[:n]
        for i, m in enumerate(moments, 1):
            job.update(stage=f"Editing clip {i} of {len(moments)}", pct=55 + int(40 * i / len(moments)))
            a, b = float(m["start"]), float(m["end"])
            name = f"clip_{i:02d}"
            vf = []
            if r.vertical: vf.append("crop=ih*9/16:ih,scale=1080:1920")
            if r.captions and r.vertical:
                make_ass(segs, a, b, d / f"{name}.ass"); vf.append(f"ass={name}.ass")
            cmd = ["ffmpeg", "-y", "-ss", str(a), "-to", str(b), "-i", "source.mp4"]
            if vf: cmd += ["-vf", ",".join(vf)]
            run(cmd + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", f"{name}.mp4"], cwd=d)
            job["clips"].append({"file": f"/files/{job_id}/{name}.mp4", "title": m.get("title", name),
                                 "start": a, "end": b})
        with zipfile.ZipFile(d / "clips.zip", "w") as z:
            for c in job["clips"]: z.write(d / Path(c["file"]).name, Path(c["file"]).name)
        src.unlink(missing_ok=True)
        job.update(stage="Done", pct=100, done=True)
    except Exception as e:
        job.update(error=str(e), done=True)

@app.post("/api/jobs")
def create(r: Req):
    if not re.match(r"https?://(www\.|m\.)?(youtube\.com|youtu\.be)/", r.url):
        raise HTTPException(400, "Paste a YouTube link.")
    jid = uuid.uuid4().hex[:10]
    JOBS[jid] = {"stage": "Starting", "pct": 0, "clips": [], "done": False, "error": None}
    threading.Thread(target=process, args=(jid, r), daemon=True).start()
    return {"id": jid}

@app.get("/api/jobs/{jid}")
def status(jid: str):
    if jid not in JOBS: raise HTTPException(404)
    return JOBS[jid]

@app.get("/api/jobs/{jid}/zip")
def zipped(jid: str):
    return FileResponse(DATA / jid / "clips.zip", filename="clips.zip")

app.mount("/files", StaticFiles(directory=DATA), name="files")
app.mount("/", StaticFiles(directory="static", html=True), name="static")
