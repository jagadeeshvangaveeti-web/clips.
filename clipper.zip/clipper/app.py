import re, threading, traceback, uuid, zipfile
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import pipeline

DATA = Path("data"); DATA.mkdir(exist_ok=True)
jobs, gate = {}, threading.Semaphore(1)  # one video at a time
app = FastAPI()

class Req(BaseModel):
    url: str
    max_clips: int = 10

def run(job_id, url, n):
    j, d = jobs[job_id], DATA / job_id
    d.mkdir(exist_ok=True)
    with gate:
        try:
            j.update(status="Downloading video", progress=5)
            src, title, dur = pipeline.download(url, d)
            j.update(title=title, status="Transcribing audio", progress=20)
            words, lines = pipeline.transcribe(src)
            j.update(status="Finding the best moments", progress=50)
            moments = pipeline.pick_moments(lines, n, dur)
            for i, m in enumerate(moments, 1):
                j.update(status=f"Editing clip {i} of {len(moments)}", progress=55 + 45 * i // len(moments))
                ass, out = f"clip_{i:02d}.ass", f"clip_{i:02d}.mp4"
                pipeline.write_ass(words, m["start"], m["end"], d / ass)
                pipeline.cut(src.name, ass, m["start"], m["end"], out, d)
                j["clips"].append({"title": m["title"], "reason": m.get("reason", ""),
                                   "url": f"/files/{job_id}/{out}", "start": m["start"], "end": m["end"]})
            with zipfile.ZipFile(d / "clips.zip", "w") as z:
                for i in range(1, len(moments) + 1):
                    z.write(d / f"clip_{i:02d}.mp4", f"clip_{i:02d}.mp4")
            src.unlink(missing_ok=True)
            j.update(status="Done", progress=100, done=True)
        except Exception as e:
            traceback.print_exc()
            j.update(status="Failed", error=str(e)[:300], done=True)

@app.post("/api/jobs")
def create(r: Req):
    if not re.match(r"^https?://(www\.|m\.)?(youtube\.com|youtu\.be)/", r.url.strip()):
        raise HTTPException(400, "Paste a YouTube link.")
    jid = uuid.uuid4().hex[:10]
    jobs[jid] = {"status": "Queued", "progress": 0, "clips": [], "done": False}
    threading.Thread(target=run, args=(jid, r.url.strip(), max(1, min(50, r.max_clips))), daemon=True).start()
    return {"id": jid}

@app.get("/api/jobs/{jid}")
def status(jid: str):
    if jid not in jobs: raise HTTPException(404)
    return jobs[jid]

@app.get("/api/jobs/{jid}/zip")
def zipped(jid: str):
    return FileResponse(DATA / jid / "clips.zip", filename="clips.zip")

app.mount("/files", StaticFiles(directory=DATA), name="files")
app.mount("/", StaticFiles(directory="static", html=True), name="static")
