import json, os, re, subprocess
from pathlib import Path
import anthropic, yt_dlp
from faster_whisper import WhisperModel

MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
_whisper = None

def whisper():
    global _whisper
    if _whisper is None:
        _whisper = WhisperModel(os.getenv("WHISPER_MODEL", "base"), compute_type="int8")
    return _whisper

def download(url, out: Path):
    opts = {"format": "bv*[height<=1080]+ba/b[height<=1080]", "merge_output_format": "mp4",
            "outtmpl": str(out / "source.%(ext)s"), "noplaylist": True, "quiet": True}
    with yt_dlp.YoutubeDL(opts) as y:
        info = y.extract_info(url, download=True)
    return out / "source.mp4", info.get("title", "video"), info.get("duration", 0)

def transcribe(path):
    segs, _ = whisper().transcribe(str(path), word_timestamps=True, vad_filter=True)
    words, lines = [], []
    for s in segs:
        lines.append((s.start, s.end, s.text.strip()))
        words += [(w.start, w.end, w.word.strip()) for w in (s.words or [])]
    return words, lines

def pick_moments(lines, n, duration):
    transcript = "\n".join(f"[{s:.0f}-{e:.0f}] {t}" for s, e, t in lines)
    prompt = f"""Pick the {n} best moments from this video transcript to turn into short vertical clips.
Rules: each clip 20-60 seconds, starts at the beginning of a thought and ends on a complete one,
clips must not overlap, strongest hook first in each. Return fewer than {n} if there are not enough
good moments. Video length: {duration:.0f}s.
Reply with ONLY a JSON array: [{{"start": seconds, "end": seconds, "title": "short title", "reason": "why it works"}}]

Transcript:
{transcript}"""
    msg = anthropic.Anthropic().messages.create(
        model=MODEL, max_tokens=8000, messages=[{"role": "user", "content": prompt}])
    data = json.loads(re.search(r"\[.*\]", msg.content[0].text, re.S).group(0))
    clips, last_end = [], -1
    for c in sorted(data, key=lambda c: c["start"]):
        s, e = max(0, float(c["start"])), min(duration or 1e9, float(c["end"]))
        if e - s >= 10 and s >= last_end:
            clips.append({**c, "start": s, "end": e}); last_end = e
    return clips[:n]

def ass_time(t):
    t = max(t, 0)
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"

HEADER = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Default,Arial,88,&H00FFFFFF,&H000000FF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,7,2,2,60,60,560,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""

def write_ass(words, start, end, path):
    ws = [w for w in words if w[0] >= start and w[1] <= end + 0.3]
    lines = []
    for i in range(0, len(ws), 3):  # 3 words per caption
        g = ws[i:i + 3]
        text = " ".join(w[2] for w in g).upper().replace("{", "(").replace("}", ")")
        t0 = g[0][0] - start
        t1 = (ws[i + 3][0] if i + 3 < len(ws) else g[-1][1]) - start
        lines.append(f"Dialogue: 0,{ass_time(t0)},{ass_time(t1)},Default,,0,0,0,,{text}")
    Path(path).write_text(HEADER + "\n".join(lines), encoding="utf-8")

def cut(source, ass_name, start, end, out_name, cwd):
    subprocess.run(["ffmpeg", "-y", "-ss", str(start), "-t", str(end - start), "-i", source,
        "-vf", f"crop=ih*9/16:ih,scale=1080:1920,ass={ass_name}",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-c:a", "aac", "-b:a", "128k",
        "-movflags", "+faststart", out_name], cwd=cwd, check=True, capture_output=True)
