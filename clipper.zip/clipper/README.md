# Clipper

Paste a YouTube link, choose 1–50 clips, get vertical captioned clips.

## Run on your computer
Needs Python 3.10+ and ffmpeg installed.

    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=your_key   # optional: smarter moment picking
    uvicorn server:app --port 8000

Open http://localhost:8000

## Put it online
Push this folder to GitHub, then deploy it on Render, Railway or Fly.io as a
Docker web service (the Dockerfile installs ffmpeg). Use a plan with 2+ GB RAM.
Add ANTHROPIC_API_KEY as an environment variable.

Without an API key it still works, but picks moments by speech activity instead of AI.
Only clip videos you own or have permission to use.
